import json
from pathlib import Path
import streamlit as st
import streamlit.components.v1 as components

BASE=Path(__file__).parent
DATA=json.loads((BASE/'rodokmen_data.json').read_text(encoding='utf-8'))
NODES=DATA['nodes']; EDGES=DATA['edges']; STATS=DATA['stats']

st.set_page_config(page_title='Rodokmen', page_icon='🌳', layout='wide')
st.title('🌳 Rodokmen')
st.caption('Interaktivní zobrazení rodokmenu z ODS s doplněním údajů z GEDCOMu.')

# Index and graph helpers
byid={n['id']:n for n in NODES}
adj={n['id']:set() for n in NODES}
for e in EDGES:
    adj[e['source']].add(e['target']); adj[e['target']].add(e['source'])

def neighborhood(start, generations=4):
    if not start: return set(byid)
    seen={start}; frontier={start}
    for _ in range(generations):
        nxt=set()
        for u in frontier: nxt.update(adj[u]-seen)
        seen |= nxt; frontier=nxt
        if not frontier: break
    return seen

labels={n['id']:n['name'] for n in NODES}
# Keep duplicate names distinguishable in selectbox.
options=[]
counts={}
for n in NODES:
    counts[n['name']]=counts.get(n['name'],0)+1
for n in NODES:
    label=n['name'] if counts[n['name']]==1 else f"{n['name']}  [{n['row']},{n['col']}]"
    options.append((label,n['id']))

with st.sidebar:
    st.header('Zobrazení')
    mode=st.radio('Režim', ['Celý rodokmen','Od vybrané osoby'], index=0)
    selected=None
    generations=4
    if mode=='Od vybrané osoby':
        label=st.selectbox('Vyber osobu', [x[0] for x in options], index=0)
        selected=dict(options)[label]
        generations=st.slider('Počet generací / vazeb', 1, 8, 4)
    st.divider()
    st.write(f"**ODS:** {STATS['ods_person_cells']} osobních záznamů")
    st.write(f"**Různých jmen:** {STATS['ods_distinct_names']}")
    st.write(f"**GEDCOM:** {STATS['ged_people']} osob")
    st.write(f"**Doplněno z GEDCOM:** {STATS['matched_unique']}")
    st.write(f"**Nejednoznačné shody:** {STATS['ambiguous']}")
    st.write(f"**Bez shody:** {STATS['unmatched']}")

keep=neighborhood(selected,generations) if mode=='Od vybrané osoby' else set(byid)
subnodes=[n for n in NODES if n['id'] in keep]
subedges=[e for e in EDGES if e['source'] in keep and e['target'] in keep]

st.subheader(f"{mode}: {len(subnodes)} osob")

# HTML graph. D3 is loaded from a CDN; the browser needs internet access for the library.
payload=json.dumps({'nodes':subnodes,'edges':subedges,'selected':selected},ensure_ascii=False)
html=f'''<!doctype html><html><head><meta charset="utf-8"><script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<style>html,body,#wrap{{margin:0;width:100%;height:100%;overflow:hidden;font-family:Arial,sans-serif}}#wrap{{position:relative;background:#fafafa}}svg{{width:100%;height:100%;cursor:grab}}svg:active{{cursor:grabbing}}.edge{{stroke:#999;stroke-width:1.4;opacity:.7}}.edge.spouse{{stroke:#c77;stroke-width:2}}.node rect{{stroke:#555;stroke-width:1;rx:7;ry:7}}.node text{{font-size:12px;pointer-events:none}}#info{{position:absolute;right:12px;top:12px;width:280px;max-height:calc(100% - 24px);overflow:auto;background:rgba(255,255,255,.96);border:1px solid #bbb;border-radius:8px;padding:12px;box-shadow:0 2px 10px rgba(0,0,0,.15);font-size:13px}}#info h3{{margin:0 0 8px;font-size:17px}}#hint{{position:absolute;left:12px;top:12px;background:rgba(255,255,255,.9);border:1px solid #ccc;border-radius:6px;padding:7px 10px;font-size:12px}}</style></head><body><div id="wrap"><svg></svg><div id="hint">Kolečko = zoom · tažení = posun · kliknutí = detail osoby</div><div id="info"><h3>Vyber osobu</h3>Klikni na libovolné jméno.</div></div>
<script>
const data={payload};
const W=window.innerWidth,H=window.innerHeight;
const svg=d3.select('svg'); const g=svg.append('g');
const zoom=d3.zoom().scaleExtent([0.12,4]).on('zoom',e=>g.attr('transform',e.transform)); svg.call(zoom);
const nodes=data.nodes.map(d=>({{...d}})); const by=new Map(nodes.map(d=>[d.id,d]));
const links=data.edges.map(e=>({{...e,source:by.get(e.source),target:by.get(e.target)}})).filter(e=>e.source&&e.target);
// Preserve the spreadsheet's generation columns and row order as the initial layout.
const colMax=d3.max(nodes,d=>d.col)||0; const rowMax=d3.max(nodes,d=>d.row)||1;
const x0=d=>70+d.col*((W-420)/(Math.max(1,colMax))); const y0=d=>35+(d.row/rowMax)*(H-70);
nodes.forEach(d=>{{d.x=x0(d);d.y=y0(d)}});
const edge=g.selectAll('.edge').data(links).join('line').attr('class',d=>'edge '+d.type);
const node=g.selectAll('.node').data(nodes).join('g').attr('class','node').attr('transform',d=>`translate(${{d.x}},${{d.y}})`).on('click',(ev,d)=>showInfo(d));
node.append('rect').attr('x',-70).attr('y',-15).attr('width',140).attr('height',30).attr('fill',d=>d.id===data.selected?'#dff0ff':'white');
node.append('text').attr('text-anchor','middle').attr('dy','4').text(d=>d.name.length>22?d.name.slice(0,21)+'…':d.name);
// A light force simulation only relaxes overlaps while keeping the spreadsheet structure.
const sim=d3.forceSimulation(nodes).force('link',d3.forceLink(links).id(d=>d.id).distance(90).strength(.08)).force('charge',d3.forceManyBody().strength(-35)).force('collide',d3.forceCollide(78)).force('x',d3.forceX(d=>x0(d)).strength(.45)).force('y',d3.forceY(d=>y0(d)).strength(.25)).alpha(.7).on('tick',()=>{{edge.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);node.attr('transform',d=>`translate(${{d.x}},${{d.y}})`);}});
function showInfo(d){{const i=document.getElementById('info');const p=d.info||{{}};let h='<h3>'+escapeHtml(d.name)+'</h3>'; if(d.ged_id){{h+='<div><b>GEDCOM:</b> '+escapeHtml(d.ged_id)+'</div>'; if(p.birth)h+='<div><b>Narození:</b> '+escapeHtml(p.birth)+(p.birth_place?' — '+escapeHtml(p.birth_place):'')+'</div>'; if(p.death)h+='<div><b>Úmrtí:</b> '+escapeHtml(p.death)+(p.death_place?' — '+escapeHtml(p.death_place):'')+'</div>'; if(p.sex)h+='<div><b>Pohlaví:</b> '+escapeHtml(p.sex)+'</div>'; if(p.occupation)h+='<div><b>Povolání:</b> '+escapeHtml(p.occupation)+'</div>'; if(p.married_names&&p.married_names.length)h+='<div><b>Další příjmení:</b> '+escapeHtml(p.married_names.join(', '))+'</div>';}} else if(d.ged_ids&&d.ged_ids.length){{h+='<div><b>GEDCOM:</b> více možných osob ('+d.ged_ids.length+')</div><div>'+escapeHtml(d.ged_ids.join(', '))+'</div>';}} else h+='<div>V GEDCOMu nebyla nalezena jednoznačná shoda.</div>';i.innerHTML=h;}}
function escapeHtml(s){{return String(s).replace(/[&<>'\"]/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','\\"':'&quot;'}}[c]));}}
// Fit all visible nodes initially.
setTimeout(()=>{{const box=g.node().getBBox(); if(box.width&&box.height){{const k=Math.min((W-40)/box.width,(H-40)/box.height,1); const tx=W/2-(box.x+box.width/2)*k; const ty=H/2-(box.y+box.height/2)*k; svg.call(zoom.transform,d3.zoomIdentity.translate(tx,ty).scale(k));}}}},900);
</script></body></html>'''
components.html(html,height=760,scrolling=False)

if selected:
    n=byid[selected]
    st.info(f"Vybraná osoba: **{n['name']}**. Kliknutím na osobu v grafu se zobrazí její dostupné údaje z GEDCOMu.")
else:
    st.info('Klikni na osobu v grafu. Kolečkem myši přibližuješ/oddaluješ a tažením se pohybuješ po stromu.')
